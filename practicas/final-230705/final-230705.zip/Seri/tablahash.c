#include "tablahash.h"
#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#define FAC_CARGA 0.75

/**
 * Casillas en la que almacenaremos los datos de la tabla hash.
 */
typedef struct {
  void *dato;
} CasillaHash;

/**
 * Estructura principal que representa la tabla hash.
 */
struct _TablaHash {
  CasillaHash **elems; // Cambio la definición para marcar como "eliminado"
  unsigned numElems;
  unsigned capacidad;
  FuncionCopiadora copia;
  FuncionComparadora comp;
  FuncionDestructora destr;
  FuncionHash hash;
};

/**
 * Crea una nueva tabla hash vacia, con la capacidad dada.
 */
TablaHash tablahash_crear(unsigned capacidad, FuncionCopiadora copia,
                          FuncionComparadora comp, FuncionDestructora destr,
                          FuncionHash hash) {

  // Pedimos memoria para la estructura principal y las casillas.
  TablaHash tabla = malloc(sizeof(struct _TablaHash));
  assert(tabla != NULL);
  tabla->elems = calloc(capacidad, sizeof(CasillaHash*));
  assert(tabla->elems != NULL);
  tabla->numElems = 0;
  tabla->capacidad = capacidad;
  tabla->copia = copia;
  tabla->comp = comp;
  tabla->destr = destr;
  tabla->hash = hash;

  // Inicializamos las casillas con datos nulos.
  // for (unsigned idx = 0; idx < capacidad; ++idx) {
  //   tabla->elems[idx]->dato = NULL;
  // }

  return tabla;
}

/**
 * Retorna el numero de elementos de la tabla.
 */
int tablahash_nelems(TablaHash tabla) { return tabla->numElems; }

/**
 * Retorna la capacidad de la tabla.
 */
int tablahash_capacidad(TablaHash tabla) { return tabla->capacidad; }

// -----------------------

int casilla_vacia(CasillaHash* casilla) {
  if (casilla) return casilla->dato ? 0 : 1;
  return 1;
}

/**
 * Retorna el dato de la tabla que coincida con el dato dado, o NULL si el dato
 * buscado no se encuentra en la tabla.
 */
void *tablahash_buscar(TablaHash tabla, void *dato) {

  // Calculamos la posicion del dato dado, de acuerdo a la funcion hash.
  unsigned idx = tabla->hash(dato) % tabla->capacidad;

  // Retornar NULL si la casilla estaba vacia.
  if (!tabla->elems[idx])
    return NULL;
  // Retornar el dato de la casilla si hay concidencia.

  int condicion = 0;
  void *dato_buscado = NULL;
  for (int i = 0; !condicion && i < tabla->capacidad; i++) {
    idx = (tabla->hash(dato)+i) % tabla->capacidad;
    // printf("Indice %i con i:%i, con dato: %s\n", idx, i, (char*) tabla->elems[idx]->dato);
    if (!casilla_vacia(tabla->elems[idx]) && tabla->comp(tabla->elems[idx]->dato, dato) == 0) {
      // printf("Entra: %s\n", (char *)tabla->elems[idx]->dato);
      dato_buscado = tabla->copia(tabla->elems[idx]->dato);
      condicion = 1;
    }
  }
  return condicion ? dato_buscado : NULL;
}

/**
 * Destruye la tabla.
 */
void tablahash_destruir(TablaHash tabla) {

  if (!tabla) return;

  for (int i = 0; i < tabla->capacidad; i++) {
    if(tabla->elems[i]) {
      if (tabla->elems[i]->dato) tabla->destr(tabla->elems[i]->dato);
      free(tabla->elems[i]);
    }
  }
  free(tabla->elems);
  free(tabla);

  // COMPLETAR
}

/**
 * Inserta un dato en la tabla, o lo reemplaza si ya se encontraba.
 */
void tablahash_insertar(TablaHash tabla, void *dato) {

  if (!tabla) return;

  float factor_carga = (float)tabla->numElems / tabla->capacidad;
  if (factor_carga > FAC_CARGA) {
    printf("Redimensionando\n");
    tablahash_redimensionar(tabla);
    printf("Redimensionado\n");
  }
  tabla->numElems++;

  int condicion = 0;
  printf("Cant elementos: %i\n", tabla->numElems);
  for (int i = 0; !condicion && i < tabla->capacidad; i++) {
    int idx = (tabla->hash(dato)+i) % tabla->capacidad;
    // printf("Indice: %i\n", idx);
    // printf("Memoria: %p\n", tabla->elems[idx]);
    if (!tabla->elems[idx]) {
      printf("Indice: %i\n", idx);
      tabla->elems[idx] = malloc(sizeof(CasillaHash));
      tabla->elems[idx]->dato = tabla->copia(dato);
      condicion = 1;
    }
    else if (casilla_vacia(tabla->elems[idx])) {
      tabla->elems[idx]->dato = tabla->copia(dato);
      printf("%s\n", (char*)tabla->elems[idx]->dato);
      condicion = 1;
    }
  }

  // COMPLETAR
}

/**
 * Elimina el dato de la tabla que coincida con el dato dado.
 */
void tablahash_eliminar(TablaHash tabla, void *dato) {

  int condicion = 0;
  for (int i = 0; !condicion && i < tabla->capacidad; i++) {
    if (!casilla_vacia(tabla->elems[i]) && tabla->comp(tabla->elems[i]->dato, dato) == 0) {
      printf("Destruido!: %s\n", (char*) tabla->elems[i]->dato);
      tabla->destr(tabla->elems[i]->dato);
      tabla->elems[i]->dato = NULL;
      condicion = 1;
    }
  }

  // COMPLETAR
}

/*
 * Redimensiona la tabla al doble de su tamaño.
 */
void tablahash_redimensionar(TablaHash tabla) {

  CasillaHash **viejos_elems = tabla->elems;
  unsigned vieja_capacidad = tabla->capacidad;
  tabla->capacidad *= 2;
  tabla->elems = calloc(tabla->capacidad, sizeof(CasillaHash*));
  
  int x = 0;

  for (int i = 0; i < vieja_capacidad; i++) {
    if (!casilla_vacia(viejos_elems[i])) {
      // Dedicidi no utilizar insertar para no copiar todos los datos.
      void *dato = viejos_elems[i]->dato;
      int condicion = 0;
      for (int k = 0; !condicion; k++) {
        int idx = (tabla->hash(dato)+k) % tabla->capacidad;
        if (!tabla->elems[idx]) {
          printf("%s con nuevo indice: %i\n", (char*) dato, idx);
          tabla->elems[idx] = viejos_elems[i];
          condicion = 1;
        }
      }
    }
  }
  free(viejos_elems);
  return;
}

/**
 * Devuelve el tamaño del cluster primario más grande.
 */
int tablahash_max_cluster(TablaHash tabla) {

  int max = 0;
  int cluster_actual = 0;

  for (int i = 0; i < tabla->capacidad; i++) {
    if (!tabla->elems[i]) {
      cluster_actual = 0;
    } else {
      cluster_actual++;
      if (cluster_actual > max) {
        max = cluster_actual;
      }
    }
  }

  return max;
}